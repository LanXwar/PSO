OverMounter is used to launch OverParse without triggering GameGuard errors.

If you launch OverParse directly, you will be booted from the game, so use OverMounter instead. It will generate a second executable file: you can ignore that, it's used for GameGuard evasion purposes.

Credit goes to https://github.com/Zogzer.